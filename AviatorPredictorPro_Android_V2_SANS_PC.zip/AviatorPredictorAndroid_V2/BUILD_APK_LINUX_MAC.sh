#!/bin/sh
cd "$(dirname "$0")"
if [ ! -f "./gradlew" ]; then
  echo "Gradle Wrapper non present. Ouvre ce dossier dans Android Studio puis laisse Android Studio synchroniser le projet."
  echo "Ensuite : Build > Build APK(s)."
  exit 1
fi
./gradlew :app:assembleDebug
printf '\nAPK cree : app/build/outputs/apk/debug/app-debug.apk\n'
