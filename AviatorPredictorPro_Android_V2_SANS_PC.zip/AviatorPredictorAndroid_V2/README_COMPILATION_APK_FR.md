# Aviator Predictor Pro V2 — Compiler l'APK

## Méthode recommandée : Android Studio

1. Installe Android Studio sur l'ordinateur.
2. Décompresse `AviatorPredictorPro_Android_V2.zip`.
3. Dans Android Studio : **Open** puis sélectionne le dossier `AviatorPredictorAndroid_V2`.
4. Attends la fin de **Gradle Sync**. Accepte l'installation des composants Android demandés si Android Studio les propose.
5. Dans le menu : **Build → Build APK(s)**.
6. Quand Android Studio affiche **APK(s) generated successfully**, clique sur **locate**.
7. Le fichier de debug se trouve normalement dans :
   `app/build/outputs/apk/debug/app-debug.apk`
8. Copie l'APK sur ton téléphone Android et ouvre-le pour l'installer. Si Android demande l'autorisation d'installer depuis cette source, autorise Android Studio/gestionnaire de fichiers selon le cas.

## Variante

Tu peux aussi utiliser **Build → Generate App Bundles or APKs → Generate APKs** selon la version d'Android Studio.

## Caractéristiques

- Application ID : `com.aviatorpredictor.pro`
- Version : `2.0`
- Min Android : API 23
- Cible : API 35
- Le fichier HTML de l'application est dans `app/src/main/assets/index.html`.

## Important

Le premier build peut télécharger Gradle et les composants Android nécessaires. Une connexion Internet est donc normalement requise sur l'ordinateur.

Le projet V2 est un wrapper WebView : l'interface premium et la logique HTML sont embarquées dans l'application Android.
