@echo off
setlocal
cd /d "%~dp0"
if not exist "gradlew.bat" (
  echo Gradle Wrapper non present. Ouvre ce dossier dans Android Studio puis laisse Android Studio synchroniser le projet.
  echo Ensuite : Build ^> Build APK(s).
  pause
  exit /b 1
)
call gradlew.bat :app:assembleDebug
if errorlevel 1 (
  echo.
  echo ECHEC DE COMPILATION. Ouvre le projet dans Android Studio pour voir le detail de l'erreur.
  pause
  exit /b 1
)
echo.
echo APK cree : app\build\outputs\apk\debug\app-debug.apk
pause
