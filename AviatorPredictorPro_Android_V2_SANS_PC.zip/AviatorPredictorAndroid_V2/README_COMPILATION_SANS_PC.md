# Compiler l'APK sans PC

Ce projet contient un workflow GitHub Actions qui peut compiler l'APK dans le cloud.

## Depuis un téléphone Android
1. Créer/connecter un compte GitHub sur https://github.com/
2. Créer un nouveau dépôt, par exemple `aviator-predictor-v2`.
3. Dans le dépôt, utiliser **Add file > Upload files** et envoyer tout le contenu du dossier `AviatorPredictorAndroid_V2` (pas le dossier parent lui-même).
4. Valider avec **Commit changes** sur la branche `main`.
5. Ouvrir l'onglet **Actions**.
6. Sélectionner **Build Aviator Predictor APK**.
7. Appuyer sur **Run workflow** si le workflow n'a pas démarré automatiquement.
8. Attendre la fin avec une coche verte.
9. Ouvrir l'exécution terminée, puis la section **Artifacts**.
10. Télécharger `AviatorPredictorPro-debug-apk.zip` et extraire `app-debug.apk`.
11. Installer l'APK sur le téléphone.

Le workflow utilise Java 17, Android SDK 35 et Gradle 8.7 dans GitHub Actions. Il construit un APK debug installable.
