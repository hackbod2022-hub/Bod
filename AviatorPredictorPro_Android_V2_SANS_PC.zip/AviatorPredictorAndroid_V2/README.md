# Aviator Predictor Pro — Android V2

Version 2 introduces a premium mobile interface while preserving the core behavior of the supplied HTML prototype: bookmaker access screen, 3-second countdown, local persistence of custom values, live date/time, and deterministic display of the configured values.

## Build
Open this folder in Android Studio and build the `app` module.

Application ID: `com.aviatorpredictor.pro`
Version: `2.0`
Minimum Android: API 23
Target/Compile SDK: 35

## Important
The displayed values are local configured values; this app does not establish that a random game outcome can be predicted in advance.

## Compilation APK
Voir `README_COMPILATION_APK_FR.md` pour le guide complet. Le script `BUILD_APK_WINDOWS.bat` peut lancer la compilation après présence du Gradle Wrapper.
